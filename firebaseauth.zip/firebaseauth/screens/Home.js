import React from 'react';
import {View,Text,TouchableOpacity} from 'react-native';
import {auth} from '../firebase';

export default Home=({navigation})=>{

  const handleSignOut=()=>{
    auth
      .signOut()
      .then(()=>{
        navigation.replace("Login")
      })
      .catch(error=>alert(error.message))

  }

  return(
    <View
         style={{
           flex:1,
           alignItems:'center',
           justifyContent:"center",
           backgroundColor:'gray',
         }}
    >
       <Text
           style={{
              fontSize:25,
              fontWeight:'bold',
              color:'pink',
              
           }}
       >Welcome</Text>
       <Text
           style={{
             fontSize:20,
             color:'pink',
             marginTop:15,
           }} 
       >{auth.currentUser?.email}
       </Text>
       <TouchableOpacity
         style={{
           marginTop:15,
           
                alignItems:'center',
                justifyContent:'center',
         }}
         onPress={handleSignOut}
       > 
          <Text
              style={{
                backgroundColor:'blue',
                color:'white',
                height:50,
                width:200,
                borderRadius:15,
                alignItems:'center',
                justifyContent:'center',
                borderWidth:1,
                borderColor:'pink',
                fontSize:18,
                fontWeight:'bold',
                paddingTop:12,
                paddingLeft:70,
              }}
          >Logout
          </Text>
       </TouchableOpacity>
    </View>
  )
}