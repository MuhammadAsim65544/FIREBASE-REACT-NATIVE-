import React,{useState,useEffect} from 'react';
import {View,TextInput,Text,StyleSheet,TouchableOpacity,KeyboardAvoidingView} from 'react-native';
import {auth} from '../firebase'; 

export default Login=({navigation})=>{
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')


  const handleLogin=()=>{
    auth
      .signInWithEmailAndPassword(email,password)
      .then(userCredentials=>{
        const user=userCredentials.user;
        console.log('Logged in with: ',user.email)
        navigation.replace("Home");
      })
      .catch(error=>alert(error.message))
  }

  return(
    <View
       style={{
         flex:1,
         backgroundColor:'gray',
        alignItems:'center',
        justifyContent:'center'
       }}
    >
        <Text
            style={{
              color:'pink',
              fontSize:18,
              marginTop:80,
              fontWeight:'bold',
            }}
        >Login Screen
        </Text>

        <Text
            style={{
              color:'white',
              fontSize:15,
              paddingRight:180,
              paddingTop:30,
            }}
        > Enter Email
        </Text>
        <TextInput
            placeholder=' Enter email'
            onChangeText={(text)=>setEmail(text)}
            style={{
              width:230,
              borderWidth:1,
              borderColor:'green',
              height:40,
              borderRadius:10,
              backgroundColor:'white',
            }}
            
        />

        <Text
            style={{
              color:'white',
              fontSize:15,
              paddingRight:150,
              paddingTop:30,
            }}
        > Enter Password
        </Text>
        <TextInput
            placeholder=' Enter password'
            onChangeText={text=>setPassword(text)}
            secureTextEntry
            style={{
                width:230,
              borderWidth:1,
              borderColor:'green',
              height:40,
              borderRadius:10,
              backgroundColor:'white',
            }}
            
        />
        <TouchableOpacity
            style={{
              marginTop:20,
            }}
            onPress={handleLogin}
        >
            <Text
               style={{
                 color:'white',
                 borderWidth:1,
                 paddingHorizontal:50,
                 paddingVertical:8,
                 fontSize:20,
                 borderColor:'pink', 
                 backgroundColor:'blue',
                 borderRadius:10,
               }}
            > Login
            </Text>       
        </TouchableOpacity>

        
        <TouchableOpacity
            style={{
              marginTop:20,
            }}
            onPress={()=>navigation.navigate("SignUp")}
        >
            <Text
               style={{
                 color:'white',
                 borderWidth:1,
                 paddingHorizontal:50,
                 paddingVertical:8,
                 fontSize:20,
                 borderColor:'pink', 
                 backgroundColor:'green',
                 borderRadius:10,
               }}
            > Register
            </Text>       
        </TouchableOpacity>
    </View>
  )
}